#ifndef _mysql_lob_h_
#define _mysql_lob_h_

#include "my_global.h"
#include <stdint.h>

#define MAX_OB_LOB_LOCATOR_HEADER_LENGTH 40

typedef struct ObLobLocator
{
  uint32_t magic_code_;
  uint32_t version_;
  int64_t snapshot_version_;
  uint64_t table_id_;
  uint32_t column_id_;
  uint16_t mode_;  // extend flag: inlin and other types
  uint16_t option_;  // storage option: compress/ encrypt / dedup
  uint32_t payload_offset_; // == rowid_size; payload = data_ + payload_offset_
  uint32_t payload_size_;
  char data_[1]; // rowid + varchar
} OB_LOB_LOCATOR;

#endif /* _mysql_lob_h_ */
